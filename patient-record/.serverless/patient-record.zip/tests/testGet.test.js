const chai = require("chai");
const chaiHttp = require("chai-http");
const app = require("../handler");

chai.expect();
chai.use(chaiHttp);

describe("API Patients", () => {
  describe("GET /patients", () => {
    it("should return a list of patients", (done) => {
      chai.request("http://localhost:3000")
      .get("/patients");
    });
  });
});